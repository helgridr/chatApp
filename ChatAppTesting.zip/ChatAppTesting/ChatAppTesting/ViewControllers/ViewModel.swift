//
//  ViewModel.swift
//  ChatAppTesting
//
//  Created by Godohaldo Perez on 10/2/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit
import MyChatFramework
import Darwin


class ViewModel{
    weak var viewController:ViewModelDelegate!
    
    var originalConstraintValue:CGFloat!
    var chat:[(message:String,sender:MessageSender)] = []
    
    init(delegate: ViewModelDelegate){
        self.viewController = delegate
    }
    func setTextFieldWidth(forViewWidth viewWidth:CGFloat){
        self.viewController.setTextFieldWidth(to: viewWidth - 100)
    }
    func setOriginalToolbarConstraint(_ constraint:CGFloat){
        self.originalConstraintValue = constraint
    }
    func getOriginalToolbarConstraint()->CGFloat{
        return self.originalConstraintValue
    }
    func getNumberOfRows()->Int{
        return chat.count
    }
    func indexPathForLastRow()->IndexPath{
        let numberOfRows = chat.count
        return IndexPath(row: numberOfRows - 1, section: 0)
    }
    
    func scrollTableViewWhenResizing(forVisibleRows indexPaths: [IndexPath]?)->Bool{
        let lastRow = indexPaths?.map{$0.row}.max()
        return lastRow == chat.count - 1 ? true : false
    }
    func addMessage(_ message:String, fromSender sender:MessageSender){
        self.chat.append((message: message, sender: sender))
        self.viewController.reloadTableView()
        self.viewController.scrollTableViewToBottom(chat.count,animated: true)
    }
    func getMessage(atIndex index:Int)->(message:String,sender:MessageSender){
        return chat[index]
    }
    func clearChat(){
        self.chat = []
        self.viewController.reloadTableView()
    }
    func niceBot(){
        let delay = Int(arc4random_uniform(11)) + 3
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(delay)) {
            self.addMessage("Nice!", fromSender: .isaiahTheTraitor)
        }
    }
}

