//
//  ViewController.swift
//  ChatAppTesting
//
//  Created by Godohaldo Perez on 9/30/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import UIKit
import MyChatFramework
import Darwin

class ViewController: UIViewController {

    @IBOutlet weak var tableView:UITableView!
    @IBOutlet weak var textField:UITextField!
    @IBOutlet weak var toolbarBottomConstraint:NSLayoutConstraint!
    @IBOutlet weak var sendButton: UIBarButtonItem!
    
    lazy var viewModel = ViewModel(delegate:self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.textField.delegate = self
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        self.viewModel.setOriginalToolbarConstraint(self.toolbarBottomConstraint.constant)
        self.tableView.allowsSelection = false
        self.viewModel.setTextFieldWidth(forViewWidth: self.view.frame.size.width)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyBoardWillAppear(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyBoardWillDissapear(_:)), name: .UIKeyboardWillHide, object: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func keyBoardWillAppear(_ sender: AnyObject){
        //print("keyboard will appear")
        guard let notification = sender as? NSNotification else{return}
        guard let info = notification.userInfo else {return}
        guard let duration = (info[UIKeyboardAnimationDurationUserInfoKey] as? NSValue) as? Double else {return}
        guard let keyboardFrame = (info[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue else {return}
        animateKeyboardAppearing(to: keyboardFrame.size.height, duration: duration)
    }

    func animateKeyboardAppearing(to height: CGFloat,duration:Double){
        UIView.animate(withDuration: duration) {
            self.toolbarBottomConstraint.constant = -height//add the magic minus sign
            self.view.layoutIfNeeded()
            guard self.viewModel.scrollTableViewWhenResizing(forVisibleRows: self.tableView.indexPathsForVisibleRows) else {return}
            self.tableView.scrollToRow(at: self.viewModel.indexPathForLastRow(), at: .bottom, animated: false)
        }
    }
    
    @objc func keyBoardWillDissapear(_ sender: AnyObject){
        guard let notification = sender as? NSNotification else{return}
        guard let info = notification.userInfo else {return}
        guard let duration = (info[UIKeyboardAnimationDurationUserInfoKey] as? NSValue) as? Double else {return}
        animateKeyboardDissappearing(duration: duration)
    }
    func animateKeyboardDissappearing(duration:Double){
        UIView.animate(withDuration: duration) {
            self.toolbarBottomConstraint.constant = self.viewModel.getOriginalToolbarConstraint()//originalConstraintValue
            self.view.layoutIfNeeded()
        }
    }
    @IBAction func sendMessage(_ sender: Any) {
        self.textField.resignFirstResponder()
        guard let text = self.textField.text else {return}
        guard text != "" else{return}
        self.textField.text = ""
        self.viewModel.addMessage(text, fromSender: .user)
        self.viewModel.niceBot()
    }
    @IBAction func tapOutsideKeyboard(_ sender: UITapGestureRecognizer) {
        guard sender.state == UIGestureRecognizerState.ended else {return}
        self.textField.resignFirstResponder()
    }
    
}

typealias TableViewFunctions = ViewController
extension TableViewFunctions:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tableView.register(UINib(nibName:"ChatTableViewCell", bundle: Bundle.init(for: ChatTableViewCell.self)), forCellReuseIdentifier: "Cell")
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "Cell") as? ChatTableViewCell else {fatalError("boom")}
        cell.loadCell(chatMessage: viewModel.getMessage(atIndex: indexPath.row))//chat[indexPath.row])
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getNumberOfRows()
    }
    override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        DispatchQueue.main.async {
            self.viewModel.setTextFieldWidth(forViewWidth: self.view.frame.size.width)// should try to animate this
            self.tableView.reloadData()//reload so that the chat bubble spike redraws.
        }
    }
}

typealias TextFieldFunctions = ViewController
extension TextFieldFunctions:UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let _ = textField.text {
            guard string != "\n" else {
                self.sendMessage(self)
                return false}//cant type enter
            return true
        }
        return false
    }
}
typealias ViewModelFunctions = ViewController
extension ViewModelFunctions:ViewModelDelegate{
    func scrollTableViewToBottom(_ numberOfRows: Int,animated:Bool) {
        let indexPath = IndexPath(row: numberOfRows - 1, section: 0)
        DispatchQueue.main.async {
            self.tableView.scrollToRow(at: indexPath, at: .bottom, animated: animated)
        }
    }
    func reloadTableView(){
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    func setTextFieldWidth(to width:CGFloat){
        DispatchQueue.main.async {
            self.textField.frame.size.width = width
            self.textField.setNeedsDisplay()
        }
    }
}
