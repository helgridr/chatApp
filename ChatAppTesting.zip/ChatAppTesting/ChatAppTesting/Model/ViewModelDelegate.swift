//
//  ViewModelDelegate.swift
//  ChatAppTesting
//
//  Created by Godohaldo Perez on 10/2/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit
protocol ViewModelDelegate:class{
    func reloadTableView()
    func scrollTableViewToBottom(_ numberOfRows:Int,animated:Bool)
    func setTextFieldWidth(to width:CGFloat)
}
