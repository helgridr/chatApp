//
//  ChatTableViewController.swift
//  MyChatFramework
//
//  Created by Godohaldo Perez on 10/1/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import UIKit
import Darwin

open class ChatTableViewController: UITableViewController {

    var chat:[(message:String,sender:MessageSender)] = []
    
    override open func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override open func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override open func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override open func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return chat.count
    }

    
    override open func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tableView.register(UINib(nibName:"ChatTableViewCell", bundle: Bundle.init(for: ChatTableViewCell.self)), forCellReuseIdentifier: "Cell")
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "Cell") as? ChatTableViewCell else {fatalError("boom")}
        //indexPath.row % 2 == 0 ? cell.loadCell(user: .user) : cell.loadCell(user: .isaiahTheTraitor)
        
        cell.loadCell(chatMessage: chat[indexPath.row])
        return cell
    }
    override open func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        DispatchQueue.main.async {
            self.tableView.reloadData()//reload so that the chat bubble spike redraws.  might be better to redesign spike so it doesnt change when rotating
            /*self.tableView.visibleCells.forEach{
             guard let cell = $0 as? ChatTableViewCell else {return}
             cell.redrawBubble()
             }*/
        }
    }
    
    open func addMessage(_ message:String, fromSender sender:MessageSender){
        self.chat.append((message: message, sender: sender))
        self.tableView.reloadData()
        let numberOfRows = self.tableView.numberOfRows(inSection: 0)
        let indexPath = IndexPath(row: numberOfRows - 1, section: 0)
        self.tableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
    }
    open func clearChat(){
        self.chat = []
        self.tableView.reloadData()
    }
    open func niceBot(){
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            self.addMessage("Nice!", fromSender: .isaiahTheTraitor)
        }
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
