//
//  ChatTableViewCell.swift
//  MyChatFramework
//
//  Created by Godohaldo Perez on 9/28/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import UIKit
import Foundation

public class ChatTableViewCell: UITableViewCell {
    
    @IBOutlet weak var leftContentViewConstraint:NSLayoutConstraint!
    @IBOutlet weak var rightContentViewConstraint:NSLayoutConstraint!
    @IBOutlet weak var TextLabelBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var chatBubble:CellContentView!
    @IBOutlet weak var message:UILabel!

    @IBInspectable var FillColorUser:UIColor = .red
    @IBInspectable var FillColorOther:UIColor = .lightGray

    
    public func loadCell(chatMessage:(message: String, sender:MessageSender)){
        
        chatBubble.bubbleType = chatMessage.sender
        chatBubble.FillColor = chatMessage.sender == .user ? FillColorUser : FillColorOther
        chatBubble.setNeedsDisplay()
        self.message.text = chatMessage.message
        switch chatMessage.sender {
        case .user:
            self.leftContentViewConstraint.constant = 2
            self.rightContentViewConstraint.constant = 38
            self.TextLabelBottomConstraint.constant = 16 + chatBubble.HeightOfTriangle
        case .isaiahTheTraitor:
            self.leftContentViewConstraint.constant = 38
            self.rightContentViewConstraint.constant = 2
            self.TextLabelBottomConstraint.constant = 16 + chatBubble.HeightOfTriangle
        }
        self.contentView.layoutIfNeeded()
    }
    
    public func redrawBubble(){
        chatBubble.setNeedsDisplay()
    }
    public func setTriangleHeight(to height:CGFloat){
        self.chatBubble.HeightOfTriangle = height
    }
    public func setTriangleWidth(to width:CGFloat){
        self.chatBubble.WidthOfTriangle = width
    }
    public func setUserColor(to color:UIColor){
        self.FillColorUser = color
    }
    public func setOtherColor(to color:UIColor){
        self.FillColorOther = color
    }
    
    override public func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        //chatBubble.bubbleType = user
        
    }

    override public func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
