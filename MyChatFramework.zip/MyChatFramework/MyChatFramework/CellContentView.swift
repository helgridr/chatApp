//
//  CellContentView.swift
//  MyChatFramework
//
//  Created by Godohaldo Perez on 9/28/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import UIKit

@objc public enum MessageSender:Int{//fix
    case user = -1
    case isaiahTheTraitor = 1
}
@IBDesignable
public class CellContentView: UIView {

    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    
    //ibinspectables are variables that show up in the storyboard
    //@IBInspectable var isIsaiahATraitor:UIColor = .clear
    
    @IBInspectable var bubbleType:MessageSender = .user//this part isnt quite working
    
    @IBInspectable var HeightOfTriangle:CGFloat = 20.0
    @IBInspectable var WidthOfTriangle:CGFloat = 40.0
    @IBInspectable var BorderRadius:CGFloat = 8.0
    @IBInspectable var StrokeWidth:CGFloat = 3.0
    @IBInspectable var StrokeColor:UIColor = .blue
    @IBInspectable var FillColor:UIColor = .green
    
    override public func draw(_ rect: CGRect) {
        // Drawing code
        
        //you need to have context first like with coredata
        let context = UIGraphicsGetCurrentContext()
        context?.translateBy(x: 0.0, y: self.bounds.size.height)//we move this like a mouse
        context?.scaleBy(x: 1.0, y: -1.0)//this is pixie dust because it didnt work without it
        
        
        let currentFrame = self.bounds
        let user: CGFloat = CGFloat(bubbleType.rawValue)
        let offset:CGFloat = /*currentUser*/ user * (currentFrame.size.width * 0.5 - WidthOfTriangle)
        
        context?.setLineJoin(.round)//alfonso has always used round
        context?.setLineWidth(StrokeWidth)
        context?.setStrokeColor(StrokeColor.cgColor)
        context?.setFillColor(FillColor.cgColor)
        
        context?.beginPath()
        
        //triangle
        context?.move(to: CGPoint(
            x: BorderRadius + StrokeWidth + 0.5,
            y: StrokeWidth + HeightOfTriangle + 0.5))//the 0.5 is magic
        
        context?.addLine(to: CGPoint(
            x: round(currentFrame.size.width * 0.5 - WidthOfTriangle * 0.5) + 0.5 + offset,
            y: HeightOfTriangle + StrokeWidth + 0.5 ))
        context?.addLine(to: CGPoint(
            x: round(currentFrame.size.width * 0.5 + user * WidthOfTriangle * 0.5 ) + 0.5 + offset,//i had 1.1 offset here
            y: StrokeWidth + 0.5))
        context?.addLine(to: CGPoint(
            x: round(currentFrame.size.width * 0.5 + WidthOfTriangle * 0.5) + 0.5 + offset,
            y: HeightOfTriangle + StrokeWidth + 0.5))
        
        context?.addArc(tangent1End: CGPoint(x:currentFrame.size.width - StrokeWidth - 0.5, y:StrokeWidth + HeightOfTriangle + 0.5),
                        tangent2End: CGPoint(x:currentFrame.size.width - StrokeWidth - 0.5,y: currentFrame.size.width - StrokeWidth - 0.5),//StrokeWidth - HeightOfTriangle - 0.5),
                        radius: BorderRadius - StrokeWidth)
        context?.addArc(tangent1End: CGPoint(x: currentFrame.size.width - StrokeWidth - 0.5,y: currentFrame.size.height - StrokeWidth - 0.5),
                        tangent2End: CGPoint(x: round(currentFrame.size.width * 0.5 + WidthOfTriangle * 0.5) - StrokeWidth + 0.5,y: currentFrame.size.height - StrokeWidth - 0.5),
                        radius: BorderRadius - StrokeWidth)
        context?.addArc(tangent1End: CGPoint(x:StrokeWidth + 0.5 , y: currentFrame.size.height - StrokeWidth - 0.5),
                        tangent2End: CGPoint(x:StrokeWidth + 0.5 , y: StrokeWidth + HeightOfTriangle + 0.5),
                        radius: BorderRadius - StrokeWidth)
        context?.addArc(tangent1End: CGPoint(x:StrokeWidth + 0.5 , y:StrokeWidth + HeightOfTriangle + 0.5),
                        tangent2End: CGPoint(x:currentFrame.size.width - StrokeWidth - 0.5, y: StrokeWidth + HeightOfTriangle + 0.5),
                        radius: BorderRadius - StrokeWidth)
        
        /*context?.move(to: CGPoint(
            x: BorderRadius + StrokeWidth + 0.5,
            y: StrokeWidth + HeightOfTriangle + 0.5))//the 0.5 is magic
        context?.addLine(to: CGPoint(
            x: round(currentFrame.width * 0.5 - WidthOfTriangle * 0.5) + 0.5,
            y: HeightOfTriangle + StrokeWidth + 0.5 ))
        context?.addLine(to: CGPoint(
            x: round(currentFrame.size.width * 0.5) + 0.5,
            y: StrokeWidth + 0.5))
        context?.addArc(tangent1End: CGPoint(x:currentFrame.size.width - StrokeWidth - 0.5, y:StrokeWidth + HeightOfTriangle + 0.5),
                        tangent2End: CGPoint(x:currentFrame.size.width - StrokeWidth - 0.5,y:StrokeWidth - HeightOfTriangle - 0.5),
                        radius: BorderRadius - StrokeWidth)
        context?.addArc(tangent1End: CGPoint(x: currentFrame.size.width - StrokeWidth - 0.5,y: currentFrame.size.height - StrokeWidth - 0.5),
                        tangent2End: CGPoint(x: round(currentFrame.size.width * 0.5 + WidthOfTriangle * 0.5) - StrokeWidth + 0.5,y: currentFrame.size.height - StrokeWidth - 0.5),
                        radius: BorderRadius - StrokeWidth)
        context?.addArc(tangent1End: CGPoint(x:StrokeWidth + 0.5 , y: currentFrame.size.height - StrokeWidth - 0.5),
                        tangent2End: CGPoint(x:StrokeWidth + 0.5 , y: currentFrame.size.height + StrokeWidth + HeightOfTriangle + 0.5),
                        radius: BorderRadius - StrokeWidth)
        context?.addArc(tangent1End: CGPoint(x:StrokeWidth + 0.5 , y: currentFrame.size.height + StrokeWidth + HeightOfTriangle + 0.5),
                        tangent2End: CGPoint(x:currentFrame.size.width - StrokeWidth - 0.5, y: currentFrame.size.height + StrokeWidth + HeightOfTriangle + 0.5),
                        radius: BorderRadius - StrokeWidth)*/
        
        context?.closePath()
        context?.drawPath(using: .fillStroke)
    }
    //we also need a custom tableview that scrolls to the bottom when we get a new message 

}
